//Student Name:Seth Naquin
//LSU ID:897271259
//Lab Section: 1
//Assignment:YoMommaLab
//Submission Time: 4:48
package yomommatranslator;

import java.util.*;
import java.io.FileNotFoundException;
import java.io.File;

public class YoMommaTranslator {

    public static void main(String[] args) throws FileNotFoundException {

        Map<String, String> acronyms = new TreeMap<>();

        File input = new File("acronyms.txt");

        Scanner in = new Scanner(input);

        String line;

        while (in.hasNextLine()) {

            line = in.nextLine();

            String[] splitted = line.split("\\t");

            acronyms.put(splitted[0], splitted[1]);
        }
        //String acronym = acronyms.keySet().toArray().toString();
        System.out.println("Insert text to your Mother");

        Scanner userIn = new Scanner(System.in).useDelimiter("\\n");

        String text = userIn.next().toUpperCase();
        String[] split = text.split("\\s+");

        String expanded = "";

        for (int x = 0; x < split.length; x++) {
            if(acronyms.containsKey(split[x]))
                expanded += acronyms.get(split[x]) + " ";
            
            else
               expanded += split[x] + " ";
        }
        System.out.println(expanded);
    }
}
