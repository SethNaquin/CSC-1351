//Student Name: Seth Nquin
//LSU ID: 897271259
//Lab Section: 1
//Assignment: CakeProject
//Submission Time: 5:07
package cakeproject;

/**
 *
 * @author snaqu14
 */
public class Cake {

    public String flavor;
    public int tiers;
    public double price;

    public Cake(String flavor, int tiers, double price) {
        this.flavor = flavor;
        this.price = price;
        this.tiers = tiers;
    }

    public void printInvoice() {
        System.out.println("A " + tiers + " tier " + flavor + " cake. The price is $" + price + ". Issued on: " + java.time.LocalDate.now());
    }

    public void printCard() {
        System.out.println("Thank you for choosing us!");
    }
}
