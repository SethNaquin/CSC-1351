//Student Name: Seth Nquin
//LSU ID: 897271259
//Lab Section: 1
//Assignment: CakeProject
//Submission Time: 5:07
package cakeproject;

/**
 *
 * @author snaqu14
 */
public class CakeProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
     WeddingCake wedCk = new WeddingCake ("chocolate" , 3, 355.0, "Sarah", "John");
    wedCk.printInvoice();
    wedCk.printCard();
    
    System.out.println();
    
    BirthDayCake bdCk = new BirthDayCake("vanilla", 1, 20.0, "Alan", 15);
    bdCk.printInvoice();
    bdCk.printCard();
    
    } 
}
