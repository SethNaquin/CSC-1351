//Student Name: Seth Nquin
//LSU ID: 897271259
//Lab Section: 1
//Assignment: CakeProject
//Submission Time: 5:07
package cakeproject;

/**
 *
 * @author snaqu14
 */
public class WeddingCake extends Cake {
    private String brideFirstName;
    private String groomFirstName;
    
    public WeddingCake(String flavor, int tiers, double price, String brideName, String groomName){
        super(flavor, tiers, price);
        this.brideFirstName = brideName;
        this.groomFirstName = groomName;
    }
    @Override
    public void printCard(){
        System.out.println("Happy wedding to " + brideFirstName + " and " + groomFirstName+ "!");
        super.printCard();
    }
}
