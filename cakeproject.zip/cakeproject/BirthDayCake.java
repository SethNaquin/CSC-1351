//Student Name: Seth Nquin
//LSU ID: 897271259
//Lab Section: 1
//Assignment: CakeProject
//Submission Time: 5:07
package cakeproject;

/**
 *
 * @author snaqu14
 */
public class BirthDayCake extends Cake{
    private String firstName;
    private int age;
    
    public BirthDayCake (String flavor, int tiers, double price, String firstName, int age){
        super (flavor, tiers, price);
        this. firstName = firstName;
        this. age = age;
    }
    @Override
    public void printCard(){
        System.out.println("Happy birthday to " + firstName + "! You just turned " + age + ":)");
        super.printCard();
    }
}
