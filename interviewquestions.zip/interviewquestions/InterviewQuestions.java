//Student Name:Seth Naquin
//LSU ID:897271259
//Lab Section: 1
//Assignment:InterviewQuestions
//Submission Time: 
package interviewquestions;

import java.util.*;

public class InterviewQuestions {

    public static void main(String[] args) {

        System.out.println(isPalendrome("Racecar"));
        System.out.println(isPalendrome("steve"));
        System.out.println(isBalancedExpression("{}{}({()})"));
        System.out.println(isBalancedExpression("((){}{}"));
        System.out.println(EvaluateExpression("42+351-*+"));
        System.out.println(EvaluateExpression("545*+5/"));
    }

    public static boolean isPalendrome(String input) {

        char[] chars = input.toCharArray();

        Stack<Character> myStack = new Stack<>();

        for (int x = 0; x < chars.length; x++) {

            myStack.push(chars[x]);
        }
        String reverse = "";

        for (int x = 0; x < chars.length; x++) {

            reverse += myStack.pop();
        }
        if (input.equalsIgnoreCase(reverse)) {

            return true;
        }
        return false;
    }

    public static boolean isBalancedExpression(String expression) {

        char[] chars = expression.toCharArray();

        Stack<Character> myStack = new Stack<>();

        for (int x = 0; x < chars.length; x++) {

            if (chars[x] == '(' || chars[x] == '{') {

                myStack.push(chars[x]);
            } 
            else if (chars[x] == ')' || chars[x] == '}') {

                char op = myStack.pop();

                if ((op == '(' && chars[x] != ')') || (op == '{' && chars[x] != '}')) {
                    return false;

                }

            }
        }
        if (myStack.size() == 0) {
            return true;
        }
        return false;
    }

    public static int EvaluateExpression(String expression) {

        char[] chars = expression.toCharArray();

        Stack<Integer> myStack = new Stack<>();

        for (int x = 0; x < chars.length; x++) {
            if (Character.isDigit(chars[x])) {
                myStack.push(Character.getNumericValue(chars[x]));
            } 
            
            else if (chars[x] == '+' || chars[x] == '-' || chars[x] == '*' || chars[x] == '/') {
                int num1 = myStack.pop();
                int num2 = myStack.pop();
                if (chars[x] == '+') {
                    myStack.push(num2 + num1);
                }
                if (chars[x] == '-') {
                    myStack.push(num2 - num1);
                }
                if (chars[x] == '*') {
                    myStack.push(num2 * num1);
                }
                if (chars[x] == '/') {
                    myStack.push(num2 / num1);
                }
            }
        }
    return myStack.pop();
    }

}
