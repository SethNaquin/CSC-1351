//Student Name: Seth Naquin
//LSU ID: 897271259
//Lab Section: 1
//Assignment: PhonebookProject
//Submission Time: 5:54
package phonebookproject;

/**
 *
 * @author snaqu14
 */
public class Person extends Contact {

    private String Relationship;

    public Person(String name, long phone, String Relationship) {//brings super
        super(name, phone);
        this.Relationship = Relationship;
    }

    @Override
    public String getInfo() {//prints info
        return super.getInfo() + String.format("%-15s", Relationship);
    }
}
