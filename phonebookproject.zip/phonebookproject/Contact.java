//Student Name: Seth Naquin
//LSU ID: 897271259
//Lab Section: 1
//Assignment: PhonebookProject
//Submission Time: 5:54
package phonebookproject;

import java.util.ArrayList;

public class Contact implements Comparable<Contact> {

    public String name;
    public long phone;

    public Contact(String name, long phone) {

        this.name = name;
        this.phone = phone;
    }

    public String getInfo() {//prints info
        return String.format("%-20s%-15d", name, phone);
    }

    @Override
    public int compareTo(Contact other) {//compares to name
        return name.compareTo(other.name);
    }
}
