//Student Name: Seth Naquin
//LSU ID: 897271259
//Lab Section: 1
//Assignment: PhonebookProject
//Submission Time: 5:54
package phonebookproject;

/**
 *
 * @author snaqu14
 */
public class Business extends Contact {

    private int Zip;

    public Business(String name, long phone, int Zip) {//brings super
        super(name, phone);
        this.Zip = Zip;
    }

    @Override
    public String getInfo() {//prints info
        return super.getInfo() + String.format("%-15d", Zip);
    }
}
