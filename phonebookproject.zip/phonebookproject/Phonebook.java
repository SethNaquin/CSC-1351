//Student Name: Seth Naquin
//LSU ID: 897271259
//Lab Section: 1
//Assignment: PhonebookProject
//Submission Time: 5:54
package phonebookproject;

import java.util.ArrayList;

public class Phonebook {

    private ArrayList<Person> Person = new ArrayList<>();
    private ArrayList<Business> Business = new ArrayList<>();

    public void addPerson(String name, long phone, String Relationship) {//adds person
        Person.add(new Person(name, phone, Relationship));
    }

    public void addBusiness(String name, int phone, int Zip) {//adds business
        Business.add(new Business(name, phone, Zip));
    }
    public void printContacts(){
       
        
        System.out.print(String.format("%-20s%-15s%-15s\n","Person name","Phone","Relationship"));
        
        
        System.out.println("-------------------------------------------------");
        
        for(Person P: Person)
            System.out.println(P.getInfo());
            
        System.out.println("-------------------------------------------------");
        
        System.out.print(String.format("%-20s%-15s%-15s\n","Person name","Phone","Zip"));
        
        System.out.println("-------------------------------------------------");
        
        for(Business B: Business)
            System.out.println(B.getInfo());
    }
}
