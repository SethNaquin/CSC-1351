/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carsproject;

//Student Name: Seth Naquin
//LSU ID: 897271259
//Lab Section: 1
//Assignment: CarsProject
//Submission Time: 5:44pm
public class Car {
    long VIN;
    String Model;
    int Year;
    double Mileage;
    
    public Car(){}
    
    public Car(long vin, int year, String model)
    {
        VIN = vin;
        Model = model;
        Year = year;
        
    }
   
    public void setMileage(double mileage)
    {
        Mileage = mileage;
    }
    
    public String getInfo(){
       return (Year+" "+Model+" (VIN: "+VIN+" Mileage: "+Mileage+" miles)");
    }
}
                                


