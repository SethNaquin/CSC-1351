//Student Name: Seth Naquin
//LSU ID: 897271259
//Lab Section: 1
//Assignment: CarsProject
//Submission Time: 5:44pm
package carsproject;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.io.File;
import java.util.Scanner;
import java.io.FileOutputStream;
/**
 *
 * @author snaqu14
 */
public class CarsProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
    
        
        
    Car c1 = new Car(123131131, 2009, "Camary");
    c1.setMileage(60000);
    saveCarInfo(c1.getInfo());
    
    
    
    Car c2 = new Car(95645421, 2010, "Accord");
    c2.setMileage (95000);
    saveCarInfo(c2.getInfo());
    
    
    
    Car c3 = new Car(45746587, 2019, "CX5");
    c3.setMileage(600);
    saveCarInfo(c3.getInfo());
    
    
    
    }
    
    
    
    public static void saveCarInfo (String info) throws FileNotFoundException{
        PrintWriter outFile = new PrintWriter(new FileOutputStream(new File("carInfo.txt"),true));
        outFile.println(info);
        
        outFile.close();
    }
}