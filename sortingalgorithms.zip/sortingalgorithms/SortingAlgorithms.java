package sortingalgorithms;
//Student Name:Seth Naquin
//LSU ID:897271259
//Lab Section: 1
//Assignment:SortingAlgorithms
//Submission Time: 5:14

import java.util.Scanner;
import java.util.Random;
import java.time.Instant;
import java.time.Duration;

public class SortingAlgorithms {

    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Please enter the size of your file:");

        Scanner input = new Scanner(System.in);
        int listSize = input.nextInt();

        int[] array = new int[listSize];
        Random rand = new Random();

        for (int i = 0; i < listSize; i++) {
            array[i] = rand.nextInt(1000);
        }

        Instant start = Instant.now();
        //BubbleSort(array.clone());
        Instant finish = Instant.now();
       // System.out.println("Time is: " + Duration.between(start, finish).toMillis());
        //System.out.println("--------------------------------------------");

        start = Instant.now();
        //CSBubbleSort(array.clone());
        finish = Instant.now();
       // System.out.println("Time is: " + Duration.between(start, finish).toMillis());
        //System.out.println("--------------------------------------------");

        start = Instant.now();
        selectionSort(array.clone());
        finish = Instant.now();
        System.out.println("Time is: " + Duration.between(start, finish).toMillis());
        System.out.println("--------------------------------------------");
        
        start = Instant.now();
        insertionSort(array.clone());
        finish = Instant.now();
        System.out.println("Time is: " + Duration.between(start, finish).toMillis());
        System.out.println("--------------------------------------------");

        start = Instant.now();
        mergeSort(array.clone());
        finish = Instant.now();
        System.out.println("Merge Sort time is: " + Duration.between(start, finish).toMillis());
        System.out.println("--------------------------------------------");

        start = Instant.now();
        quickSort(array.clone(), 0, array.length-1);
        finish = Instant.now();
        System.out.println("Quick Sort time is: " + Duration.between(start, finish).toMillis());
        System.out.println("--------------------------------------------");

    }

    public static void BubbleSort(int[] array) {//uses bubblesort
        long counter = 0;
        for (int i = 1; i < array.length - 1; i++) {
            for (int j = 0; j < array.length - i - 1; j++) {
                if (array[j] > array[j + 1]) {
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                    counter++;
                }
            }
        }
        System.out.println("Count for Bubble Sort: " + counter / 1000);
    }

    public static void CSBubbleSort(int[] array) {//uses CSbubblesort
        long counter = 0;
        for (int i = 0; i < array.length; i++) {
            boolean swap = false;
            for (int j = 0; j < array.length - i - 1; j++) {
                if (array[j] > array[j + 1]) {
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                    swap = true;
                    counter++;
                }
            }
            if (!swap) {
                break;
            }
        }
        System.out.println("Count for Short Circut Bubble Sort: " + counter / 1000);
    }

    public static void selectionSort(int[] arr) {//uses selection sort
        long counter = 0;
        for (int i = 0; i < arr.length - 1; i++) {
            int index = i;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[j] < arr[index]) {
                    index = j;
                    counter++;
                }
            }
            int smallerNumber = arr[index];
            arr[index] = arr[i];
            arr[i] = smallerNumber;
        }
        System.out.println("Count for Selection Sort: " + counter / 1000);
    }

    public static void insertionSort(int arr[]) {//uses insertion sort
        long counter = 0;
        int i, key, j;
        for (i = 1; i < arr.length; i++) {
            key = arr[i];
            j = i - 1;
            counter++;
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
            arr[j + 1] = key;
        }
        System.out.println("Count for Insertion Sort: " + counter / 1000);
    }

    public static void mergeSort(int[] array) {
        if (array.length < 2) {
            return;
        }
        int mid = array.length / 2;
        int[] l = new int[mid];
        int[] r = new int[array.length - mid];
        for (int i = 0; i < mid; i++) {
            l[i] = array[i];
        }
        for (int i = mid; i < array.length; i++) {
            r[i - mid] = array[i];
        }
        mergeSort(l);
        mergeSort(r);
        merge(array, l, r, mid, array.length - mid);
    }

    public static void merge(int[] array, int[] l, int[] r, int left, int right) {
        int i = 0, j = 0, k = 0;
        while (i < left && j < right) {
            if (l[i] <= r[j]) {
                array[k] = l[i];
                i++;
            } else {
                array[k] = r[j];
                j++;
            }
            k++;
        }
        while (i < left) {
            array[k++] = l[i++];
        }
        while (j < right) {
            array[k++] = r[j++];
        }
    }
    public static void quickSort(int[] arr, int low, int high)
    {
        //check for empty or null array
        if (arr == null || arr.length == 0){
            return;
        }
         
        if (low >= high){
            return;
        }
 
        //Get the pivot element from the middle of the list
        int middle = low + (high - low) / 2;
        int pivot = arr[middle];
 
        // make left < pivot and right > pivot
        int i = low, j = high;
        while (i <= j)
        {
            //Check until all values on left side array are lower than pivot
            while (arr[i] < pivot)
            {
                i++;
            }
            //Check until all values on left side array are greater than pivot
            while (arr[j] > pivot)
            {
                j--;
            }
            //Now compare values from both side of lists to see if they need swapping
            //After swapping move the iterator on both lists
            if (i <= j)
            {
                swap (arr, i, j);
                i++;
                j--;
            }
        }
        //Do same operation as above recursively to sort two sub arrays
        if (low < j){
            quickSort(arr, low, j);
        }
        if (high > i){
            quickSort(arr, i, high);
        }
    }
     
    public static void swap (int array[], int x, int y)
    {
        int temp = array[x];
        array[x] = array[y];
        array[y] = temp;
    }
}

