//Student Name:Seth Naquin
//LSU ID:897271259
//Lab Section: 1
//Assignment:BookStoreProject
//Submission Time: 6:03
package bookstoreproject;

import java.util.ArrayList;
import java.util.Collections;

public class BookStore {

    private String address;
    private String name;
    private ArrayList<Book> books = new ArrayList<>();

    public BookStore(String address, String name) {
        this.address = address;
        this.name = name;
    }

    public void addBook(Book b) {
        books.add(b);
    }

    public void sortBooks() {
        Collections.sort(books);
    }

    public void listBooks() {
        for (Book b : books) {
           System.out.println(b.getInfo());
        }
    }
}
