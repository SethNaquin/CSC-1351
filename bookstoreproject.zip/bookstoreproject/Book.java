//Student Name:Seth Naquin
//LSU ID:897271259
//Lab Section: 1
//Assignment:BookStoreProject
//Submission Time: 6:03
package bookstoreproject;

import java.util.ArrayList;
import java.util.Collections;

public class Book implements Comparable<Book> {

    private String title;
    private String author;
    private int edition;
    private double price;

    public Book(String title, String author, int edition, double price) {
        this.author = author;
        this.edition = edition;
        this.price = price;
        this.title = title;

    }

    public String getInfo() {
        return String.format("%-15s%-15s%-10d%-10f", title.substring(0, 10), author.substring(0,10), edition, price);
    }
    
    @Override
        public int compareTo(Book other){
            return title.compareTo(other.title);
        }
    }

