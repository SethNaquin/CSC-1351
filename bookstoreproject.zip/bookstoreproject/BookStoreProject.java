//Student Name:Seth Naquin
//LSU ID:897271259
//Lab Section: 1
//Assignment:BookStoreProject
//Submission Time: 6:03
package bookstoreproject;

/**
 *
 * @author snaqu14
 */
public class BookStoreProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
        BookStore myStore = new BookStore("Highland road, LSU, 70808", "LSU Book Store");
        
        myStore.addBook(new Book("Bad Blood: Secrets and Lies in a Silicon Valley Startup", "John Carreyrou", 1, 12.97));
        myStore.addBook(new Book("The Hundred-Page Machine Learning Book", "Andriy Burkov", 1, 30.54));
        myStore.addBook(new Book("The Code Book: The Science of Secrecy from Ancient Egypt to Quantum Cryptography", "Simon Singh", 1, 13.60));
        myStore.addBook(new Book("Don't Make Me Think, Revisited: A Common Sense Approach to Web Usability", "Steve Krug", 3, 31.33));
        myStore.addBook(new Book("Hooked: How to Build Habit-Forming Products", "Nir Eyal and Dave Wright", 1, 18.36));
        
        myStore.listBooks();
        myStore.sortBooks();
        myStore.listBooks();
}}
